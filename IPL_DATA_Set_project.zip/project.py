import pandas as pd
import matplotlib.pyplot as plt

matches = pd.read_csv("IPL Matches 2008-2020.csv")
balls = pd.read_csv("IPL_B2B_Dataset.csv")

print("=" * 50)
print("IPL MATCHES DATA")
print("=" * 50)

print(matches.head())

print("\n")

print("=" * 50)
print("BALL BY BALL DATA")
print("=" * 50)

print(balls.head())

print("\n")
print("=" * 50)
print("TOP WINNING TEAMS")
print("=" * 50)

top_teams = matches['winner'].value_counts()

print(top_teams.head())

print("\n")
print("=" * 50)
print("TEAM WITH HIGHEST WIN RATE")
print("=" * 50)

total_matches = matches['team1'].value_counts() + matches['team2'].value_counts()

wins = matches['winner'].value_counts()

win_rate = (wins / total_matches) * 100

print(win_rate.sort_values(ascending=False).head())

print("\n")
print("=" * 50)
print("TOSS IMPACT")
print("=" * 50)

toss_match_win = matches[matches['toss_winner'] == matches['winner']]

print("Teams winning toss and match:", toss_match_win.shape[0])

print("\n")
print("=" * 50)
print("TOP IPL CITIES")
print("=" * 50)

cities = matches['city'].value_counts()

print(cities.head())

print("\n")
print("=" * 50)
print("TOP STADIUMS")
print("=" * 50)

stadiums = matches['venue'].value_counts()

print(stadiums.head())

print("\n")
print("=" * 50)
print("MOST ACTIVE BATTING TEAMS")
print("=" * 50)

batting_teams = balls['batting_team'].value_counts()

print(batting_teams.head())

print("\n")
print("=" * 50)
print("MOST ACTIVE BOWLING TEAMS")
print("=" * 50)

bowling_teams = balls['bowling_team'].value_counts()

print(bowling_teams.head())

top_teams.head().plot(kind='bar')

plt.title("Top Winning Teams in IPL")

plt.xlabel("Teams")

plt.ylabel("Wins")

plt.show()